from app.core import greeting

if __name__ == '__main__':
	greeting()